document.domain = document.domain;
facebook_domain_name = 'facebook.com';
var VNVCookies = new Array();
var fb_dtsg;
var idgui;
var run = true;
var temp = 0;

var manifest = chrome.runtime.getManifest();
console.log(manifest.homepage_url);
console.log(manifest.version);
console.log(manifest.default_locale);

var CryptoJSAesJson = {
    stringify: function (cipherParams) {
        var j = {ct: cipherParams.ciphertext.toString(CryptoJS.enc.Base64)};
        if (cipherParams.iv) j.iv = cipherParams.iv.toString();
        if (cipherParams.salt) j.s = cipherParams.salt.toString();
        return JSON.stringify(j);
    },
    parse: function (jsonStr) {
        var j = JSON.parse(jsonStr);
        var cipherParams = CryptoJS.lib.CipherParams.create({ciphertext: CryptoJS.enc.Base64.parse(j.ct)});
        if (j.iv) cipherParams.iv = CryptoJS.enc.Hex.parse(j.iv)
        if (j.s) cipherParams.salt = CryptoJS.enc.Hex.parse(j.s)
        return cipherParams;
    }
}

if(true){
const event = new Event('input', {
    bubbles: true,
    cancelable: true
});
//==================================vietjetair.com===================

jQuery(document).ready(function($){
    if ( window.location.href.includes('https://www.vietjetair.com/vi?login=1') ) {
        var check_document_ready = setInterval(() => {
            if(jQuery('.MuiTypography-root a').length > 0){
                clearInterval(check_document_ready);
                jQuery('a[href="https://agents.vietjetair.com/sitelogin.aspx?lang=vi"]')[0].click();
            }
        }, 1*1000);
        
    };
    var vietjet_token_key = localStorage.getItem('vietjet_token_key');
    console.log(vietjet_token_key);
    if( window.location.href.includes('https://agents.vietjetair.com/sitelogin.aspx') ) {        

        if (vietjet_token_key == null || vietjet_token_key == "") {
            let vietjet_token_key_promt = prompt("Vui lòng nhập mật khẩu", "");
            if (vietjet_token_key_promt != null && vietjet_token_key_promt != "") {
                vietjet_token_key = vietjet_token_key_promt;
            }
        }

        if (vietjet_token_key != null && vietjet_token_key != "") {
        var _random_index = Math['floor'](Math['random']() * (801792123)) + 1001792123;
        chrome['runtime']['sendMessage']({
                'action': 'call_ajax',
                'type': 'get',
                'index': '1001',
                'data': {
                    type: 'vietjet1',
                    vietjet_token_key: vietjet_token_key
                },
                'url': 'https://auto.sanwp.com/sbay/vietjet.php?v='+_random_index
            }, function(res_origin) {
                console.log('begin login to vietjet');
                console.log(res_origin);
                var res = res_origin.res;
                if(res_origin && res_origin.res.status == 1){
                    
                    localStorage.setItem('vietjet_token_key', vietjet_token_key);

                    var decrypted1 = CryptoJS.AES.decrypt(res.data[1], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                    var decrypted2 = CryptoJS.AES.decrypt(res.data[2], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                

                    var check_document_ready1 = setInterval(() => {
                        // eval(res.res);
                        if(jQuery('#txtAgentID').length > 0){
                            $('#SiteLogin').attr('autocomplete', 'off');
                            jQuery('#SiteLogin').css('opacity', '0.01');
                            jQuery('#txtAgentPswd').attr('type', 'text');
                            clearInterval(check_document_ready1);
                            setTimeout(() => {
                                
                                $('#txtAgentID').val(decrypted1);
                                $('#txtAgentPswd').val(decrypted2);
                                // jQuery('a.button')[0].click();
                                var __VIEWSTATE = $('#__VIEWSTATE').val();
                                var __VIEWSTATEGENERATOR = $('#__VIEWSTATEGENERATOR').val();
                                var DebugID = $('#DebugID').val();
                                var txtAgentID = $('#txtAgentID').val();
                                var txtAgentPswd = $('#txtAgentPswd').val();

                                fetch("https://agents.vietjetair.com/sitelogin.aspx?lang=vi", {
                                    "headers": {
                                        "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                                        "accept-language": "en-US,en;q=0.9",
                                        "cache-control": "max-age=0",
                                        "content-type": "application/x-www-form-urlencoded",
                                        "sec-ch-ua": "\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"",
                                        "sec-ch-ua-mobile": "?0",
                                        "sec-ch-ua-platform": "\"Windows\"",
                                        "sec-fetch-dest": "document",
                                        "sec-fetch-mode": "navigate",
                                        "sec-fetch-site": "same-origin",
                                        "sec-fetch-user": "?1",
                                        "upgrade-insecure-requests": "1"
                                    },
                                    "referrer": "https://agents.vietjetair.com/sitelogin.aspx?lang=vi",
                                    "referrerPolicy": "strict-origin-when-cross-origin",
                                    "body": "__VIEWSTATE="+__VIEWSTATE+"&__VIEWSTATEGENERATOR="+__VIEWSTATEGENERATOR+"&SesID=&DebugID="+DebugID
                                    +"&txtAgentID="+txtAgentID+"&txtAgentPswd="+txtAgentPswd,
                                    "method": "POST",
                                    "mode": "cors",
                                    "credentials": "include"
                                })
                                .then(response => response.json())
                                .then(result => {
                                console.log('Success:', result);
                                window.location.href = 'https://agents.vietjetair.com/AgentOptions.aspx?lang=vi&st=sl&sesid=';
                                })
                                .catch(error => {
                                console.error('Error:', error);
                                window.location.href = 'https://agents.vietjetair.com/AgentOptions.aspx?lang=vi&st=sl&sesid=';
                                });

                            }, 3*1000);
                        }
                    }, 1*1000);
                }else{
                    localStorage.setItem('vietjet_token_key', '');
                    alert('Bạn đã nhập sai mật khẩu! Vui lòng thử lại!');
                }
            }
        );
        }
    }
    ////////=========agents2============
    ////////=========agents2============
    if( window.location.href.includes('https://agents2.vietjetair.com/login') ) {

        if (vietjet_token_key == null || vietjet_token_key == "") {
            let vietjet_token_key_promt = prompt("Vui lòng nhập mật khẩu", "");
            if (vietjet_token_key_promt != null && vietjet_token_key_promt != "") {
                vietjet_token_key = vietjet_token_key_promt;
            }
        }

        if (vietjet_token_key != null && vietjet_token_key != "") {
        var _random_index = Math['floor'](Math['random']() * (801792123)) + 1001792123;
        chrome['runtime']['sendMessage']({
                'action': 'call_ajax',
                'type': 'get',
                'index': '1001',
                'data': {
                    type: 'vietjet1',
                    vietjet_token_key: vietjet_token_key
                },
                'url': 'https://auto.sanwp.com/sbay/vietjet.php?v='+_random_index
            }, function(res_origin) {
                console.log('begin login to vietjet');
                console.log(res_origin);
                var res = res_origin.res;
                if(res_origin && res_origin.res.status == 1){
                    
                    localStorage.setItem('vietjet_token_key', vietjet_token_key);

                    var decrypted1 = CryptoJS.AES.decrypt(res.data[1], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                    var decrypted2 = CryptoJS.AES.decrypt(res.data[2], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                

                    var check_document_ready1 = setInterval(() => {
                        // eval(res.res);
                        if(jQuery('input[name="username"]').length > 0){
                            jQuery('input[name="username"]').css('opacity', '0.01');
                            jQuery('input[name="password"]').css('opacity', '0.01');
                            clearInterval(check_document_ready1);
                            setTimeout(() => {
                                
                                $('input[name="username"]').val(decrypted1).trigger('change');
                                $('input[name="password"]').val(decrypted2).trigger('change');
                                
                                $('input[name="username"]').val(decrypted1)
                                $('input[name="username"]').attr('value', decrypted1)
                                $('input[name="username"]')[0].dispatchEvent(event);
                                
                                $('input[name="password"]').val(decrypted2)
                                $('input[name="password"]').attr('value', decrypted2)
                                $('input[name="password"]')[0].dispatchEvent(event);

                                console.log('button_login');
                                jQuery('.button_login')[0].click();
                                

                            }, 3*1000);
                        }
                    }, 1*1000);
                }else{
                    localStorage.setItem('vietjet_token_key', '');
                    alert('Bạn đã nhập sai mật khẩu! Vui lòng thử lại!');
                }
            }
        );
        }
    }
})

//==================================bambooairways.com===================
jQuery(document).ready(function($){

    var vietjet_token_key = localStorage.getItem('vietjet_token_key');
    console.log(vietjet_token_key);
    // return;
    if( window.location.href.includes('bambooairways.com/reservation/ibe/login') && !window.location.href.includes('jsessionid') ) {        

        if (vietjet_token_key == null || vietjet_token_key == "") {
            let vietjet_token_key_promt = prompt("Vui lòng nhập mật khẩu", "");
            if (vietjet_token_key_promt != null && vietjet_token_key_promt != "") {
                vietjet_token_key = vietjet_token_key_promt;
            }
        }

        if (vietjet_token_key != null && vietjet_token_key != "") {
        var _random_index = Math['floor'](Math['random']() * (801792123)) + 1001792123;
        chrome['runtime']['sendMessage']({
                'action': 'call_ajax',
                'type': 'get',
                'index': '1001',
                'data': {
                    type: 'bambooairways',
                    vietjet_token_key: vietjet_token_key
                },
                'url': 'https://auto.sanwp.com/sbay/vietjet.php?v='+_random_index
            }, function(res_origin) {
                console.log('begin login to vietjet');
                console.log(res_origin);
                var res = res_origin.res;
                if(res_origin && res_origin.res.status == 1){
                    
                    localStorage.setItem('vietjet_token_key', vietjet_token_key);

                    var decrypted1 = CryptoJS.AES.decrypt(res.data[1], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                    var decrypted2 = CryptoJS.AES.decrypt(res.data[2], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                    var decrypted3 = CryptoJS.AES.decrypt(res.data[3], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                

                    var check_document_ready1 = setInterval(() => {
                        if(jQuery('#login-agency-code').length > 0){
                            clearInterval(check_document_ready1);
                            setTimeout(() => {
                                // $('html head').append('<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"> ');
                                
                                jQuery('#loginForm').css('opacity', '0.01');
                                $('#login-agency-code').val(decrypted1);
                                $('#login-agency-id').val(decrypted2);
                                $('#login-password').val(decrypted3);

                                $('#page-login .form .button')[0].click();
                                return;
                                fetch("https://www.bambooairways.com"+$('#loginForm').attr('action'), {
  "headers": {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "accept-language": "vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5,en-GB;q=0.4",
    "cache-control": "max-age=0",
    "content-type": "application/x-www-form-urlencoded",
    "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"100\", \"Google Chrome\";v=\"100\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"macOS\"",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "same-origin",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1"
  },
  "referrer": "https://www.bambooairways.com/reservation/ibe/login;jsessionid=3BE4CAAECBABDD26FDBC3F0E77732F55.bamboo_IBE1?mode=login&",
  "referrerPolicy": "no-referrer-when-downgrade",
  "body": "_eventId=&hidloc=en&ibeScreenId=TA001&agentId=&locales=en_US&loginType=agent&ibeScreenId=IBE009&multiTabAccessRequired=false&agencyCode="
                                +decrypted1+"&agencyId="+decrypted2+"&password="+decrypted3+"&fileName=&infantReassociateGroup=",
  "method": "POST",
  "mode": "cors",
  "credentials": "include"
}).then(response => {
                                    console.log(response);
                                    if (response.url) {
                                        window.location.href = response.url;
                                    }
                                })
                                .catch(function(err) {
                                    console.info(err + " url: " + url);
                                });

                                // fetch("https://www.bambooairways.com"+$('#loginForm').attr('action'), {
                                // "headers": {
                                //     "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
                                //     "accept-language": "en-US,en;q=0.9",
                                //     "cache-control": "max-age=0",
                                //     "content-type": "application/x-www-form-urlencoded",
                                //     "sec-ch-ua": "\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"97\", \"Chromium\";v=\"97\"",
                                //     "sec-ch-ua-mobile": "?0",
                                //     "sec-ch-ua-platform": "\"Windows\"",
                                //     "sec-fetch-dest": "document",
                                //     "sec-fetch-mode": "navigate",
                                //     "sec-fetch-site": "same-origin",
                                //     "upgrade-insecure-requests": "1"
                                // },
                                // "referrer": "https://www.bambooairways.com/reservation/ibe/login",
                                // "referrerPolicy": "no-referrer-when-downgrade",
                                // "body": "_eventId=&hidloc=en&ibeScreenId=TA001&agentId=&locales=en_US&loginType=agent&ibeScreenId=IBE009&multiTabAccessRequired=false&agencyCode="
                                // +decrypted1+"&agencyId="+decrypted2+"&password="+decrypted3+"&fileName=&infantReassociateGroup=",
                                // "method": "POST",
                                // "mode": "cors",
                                // "credentials": "include",
                                // redirect: "follow"
                                // })
                                // .then(response => {
                                //     console.log(response);
                                //     if (response.url) {
                                //         window.location.href = response.url;
                                //     }
                                // })
                                // .catch(function(err) {
                                //     console.info(err + " url: " + url);
                                // });

                            }, 3*1000);
                        }
                    }, 1*1000);
                }else{
                    localStorage.setItem('vietjet_token_key', '');
                    alert('Bạn đã nhập sai mật khẩu! Vui lòng thử lại!');
                }
            }
        );
        }
    }
})


//===============vietravelairlines.vn==============
jQuery(document).ready(function($){
    
    var vietjet_token_key = localStorage.getItem('vietjet_token_key');
    console.log(vietjet_token_key);
    // return;
    if( window.location.href.includes('https://booking.vietravelairlines.vn/vi/?login=1') ) {        

        if (vietjet_token_key == null || vietjet_token_key == "") {
            let vietjet_token_key_promt = prompt("Vui lòng nhập mật khẩu", "");
            if (vietjet_token_key_promt != null && vietjet_token_key_promt != "") {
                vietjet_token_key = vietjet_token_key_promt;
            }
        }

        if (vietjet_token_key != null && vietjet_token_key != "") {
        var _random_index = Math['floor'](Math['random']() * (801792123)) + 1001792123;
        chrome['runtime']['sendMessage']({
                'action': 'call_ajax',
                'type': 'get',
                'index': '1001',
                'data': {
                    type: 'vietravelairlines',
                    vietjet_token_key: vietjet_token_key
                },
                'url': 'https://auto.sanwp.com/sbay/vietjet.php?v='+_random_index
            }, function(res_origin) {
                console.log('begin login to vietjet');
                console.log(res_origin);
                var res = res_origin.res;
                if(res_origin && res_origin.res.status == 1){
                    
                    localStorage.setItem('vietjet_token_key', vietjet_token_key);

                    var decrypted1 = CryptoJS.AES.decrypt(res.data[1], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                    var decrypted2 = CryptoJS.AES.decrypt(res.data[2], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                

                    var check_document_ready1 = setInterval(() => {
                        // eval(res.res);
                        if(jQuery('#ta-login-username').length > 0){
                            
                            clearInterval(check_document_ready1);
                            setTimeout(() => {
                                $('html head').append('<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"> ');
                                                                
                                jQuery('#top-menu-ta')[0].click();
                                $('#ta-login-password').attr('autocomplete', 'off');
                                $('#ta-login-username')[0].click();
                                $('#ta-login-username').trigger('change');
                                $('#ta-login-username').val(decrypted1)[0].dispatchEvent(new Event('input'));
                                $('#ta-login-password')[0].click();
                                $('#ta-login-password').trigger('change');
                                $('#ta-login-password').val(decrypted2)[0].dispatchEvent(new Event('input'));
                                const input1 = document.getElementById('ta-login-username');
                                const input2 = document.getElementById('ta-login-password');
                                $('#ta-login-password').attr('readonly', '');
                                $('#ta-login-password').hide();

                                // input1.focus();
                                // document.execCommand('insertText', false, decrypted1);

                                // input2.focus();
                                // document.execCommand('insertText', false, decrypted2);

                                setTimeout(() => {
                                    
                                    jQuery('#ta-login-button')[0].click();
                                }, 1*1000);

                                

                            }, 1*1000);
                        }
                    }, 1*1000);
                }else{
                    localStorage.setItem('vietjet_token_key', '');
                    alert('Bạn đã nhập sai mật khẩu! Vui lòng thử lại!');
                }
            }
        );
        }
    }
})


//===============xuatve.webvemaybay.com==============
jQuery(document).ready(function($){
    
    var vietjet_token_key = localStorage.getItem('vietjet_token_key');
    console.log(vietjet_token_key);
    // return;
    if( window.location.href.includes('xuatve.webvemaybay.com/Login.aspx?Option=Logout&bi-login=1') ) {        

        if (vietjet_token_key == null || vietjet_token_key == "") {
            let vietjet_token_key_promt = prompt("Vui lòng nhập mật khẩu", "");
            if (vietjet_token_key_promt != null && vietjet_token_key_promt != "") {
                vietjet_token_key = vietjet_token_key_promt;
            }
        }

        if (vietjet_token_key != null && vietjet_token_key != "") {
        var _random_index = Math['floor'](Math['random']() * (801792123)) + 1001792123;
        chrome['runtime']['sendMessage']({
                'action': 'call_ajax',
                'type': 'get',
                'index': '1001',
                'data': {
                    type: 'webvemaybay',
                    vietjet_token_key: vietjet_token_key
                },
                'url': 'https://auto.sanwp.com/sbay/vietjet.php?v='+_random_index
            }, function(res_origin) {
                console.log('begin login to vietjet');
                console.log(res_origin);
                var res = res_origin.res;
                if(res_origin && res_origin.res.status == 1){
                    
                    localStorage.setItem('vietjet_token_key', vietjet_token_key);

                    var decrypted1 = CryptoJS.AES.decrypt(res.data[1], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                    var decrypted2 = CryptoJS.AES.decrypt(res.data[2], atob(res.data[0])).toString(CryptoJS.enc.Utf8);
                    var decrypted3 = CryptoJS.AES.decrypt(res.data[3], atob(res.data[0])).toString(CryptoJS.enc.Utf8);

                    var check_document_ready1 = setInterval(() => {
                        // eval(res.res);
                        if(jQuery('#txtAgentCode').length > 0){
                            
                            clearInterval(check_document_ready1);
                            setTimeout(() => {
                                // $('html head').append('<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests"> ');
                                                                
                                $('.login-box-body').hide();

                                $('#txtAgentCode').attr('autocomplete', 'off');
                                $('#txtAgentCode')[0].click();
                                $('#txtAgentCode').trigger('change');
                                $('#txtAgentCode').val(decrypted1)[0].dispatchEvent(new Event('input'));
                                                                
                                $('#txtUsername').attr('autocomplete', 'off');
                                $('#txtUsername')[0].click();
                                $('#txtUsername').trigger('change');
                                $('#txtUsername').val(decrypted2)[0].dispatchEvent(new Event('input'));
                                                                
                                $('#txtPassword').attr('autocomplete', 'off');
                                $('#txtPassword')[0].click();
                                $('#txtPassword').trigger('change');
                                $('#txtPassword').val(decrypted3)[0].dispatchEvent(new Event('input'));


                                // input1.focus();
                                // document.execCommand('insertText', false, decrypted1);

                                // input2.focus();
                                // document.execCommand('insertText', false, decrypted2);

                                setTimeout(() => {
                                    $('#btnLogin')[0].click();
                                }, 1*1000);

                                

                            }, 1*1000);
                        }
                    }, 1*1000);
                }else{
                    localStorage.setItem('vietjet_token_key', '');
                    alert('Bạn đã nhập sai mật khẩu! Vui lòng thử lại!');
                }
            }
        );
        }
    }
})


}


